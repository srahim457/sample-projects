/*
Author: Shonel Rahim
Course: 135
Instructor: Raffi Khatchadourian
Assignment: Project3 holiday header file
*/
#ifndef HOLIDAY_H
#define HOLIDAY_H

#include<iostream>
#include<cstdlib>
#include<string>
#include"date.h"

using namespace std;

class holiday{
public:
	holiday(){};
	holiday(int yearIn);
	void nextHoliday(date d1, int y);
	void in_bday();
	void output();
private:
	date bday; //birthday
	date thanGiv; //thanksgiving
	date schoolDay; //first school day
	date inde_day; //independence day
};

#endif